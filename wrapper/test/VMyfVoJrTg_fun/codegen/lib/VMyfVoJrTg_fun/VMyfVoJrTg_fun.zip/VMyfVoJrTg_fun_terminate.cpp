//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VMyfVoJrTg_fun_terminate.cpp
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 27-Oct-2023 11:24:57
//

// Include Files
#include "VMyfVoJrTg_fun_terminate.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
void VMyfVoJrTg_fun_terminate()
{
}

//
// File trailer for VMyfVoJrTg_fun_terminate.cpp
//
// [EOF]
//
