//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VMyfVoJrTg_fun_initialize.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 27-Oct-2023 11:24:57
//

#ifndef VMYFVOJRTG_FUN_INITIALIZE_H
#define VMYFVOJRTG_FUN_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void VMyfVoJrTg_fun_initialize();

#endif
//
// File trailer for VMyfVoJrTg_fun_initialize.h
//
// [EOF]
//
