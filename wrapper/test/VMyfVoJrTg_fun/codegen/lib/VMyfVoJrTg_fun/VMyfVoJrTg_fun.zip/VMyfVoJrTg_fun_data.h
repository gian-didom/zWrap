//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VMyfVoJrTg_fun_data.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 27-Oct-2023 11:24:57
//

#ifndef VMYFVOJRTG_FUN_DATA_H
#define VMYFVOJRTG_FUN_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for VMyfVoJrTg_fun_data.h
//
// [EOF]
//
