/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: VMyfVoJrTg_fun_terminate.h
 *
 * MATLAB Coder version            : 23.2
 * C/C++ source code generated on  : 02-Nov-2023 11:00:55
 */

#ifndef VMYFVOJRTG_FUN_TERMINATE_H
#define VMYFVOJRTG_FUN_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void VMyfVoJrTg_fun_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for VMyfVoJrTg_fun_terminate.h
 *
 * [EOF]
 */
