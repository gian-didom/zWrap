//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VMyfVoJrTg_fun.cpp
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 27-Oct-2023 11:24:57
//

// Include Files
#include "VMyfVoJrTg_fun.h"
#include "VMyfVoJrTg_fun_types.h"

// Function Definitions
//
// Arguments    : double oyvELPSlUC
//                const char eguWQhvSLY[806075]
//                const struct0_T FieEkIcymP[24]
//                const int64m_T TWgrWEqeae[557760]
//                const cell_0 *JFDmJNevGZ
//                double *oyvELPSlUCmod
//                double *b_time
// Return Type  : void
//
void VMyfVoJrTg_fun(double oyvELPSlUC, const char[806075], const struct0_T[24],
                    const int64m_T[557760], const cell_0 *,
                    double *oyvELPSlUCmod, double *b_time)
{
  *oyvELPSlUCmod = oyvELPSlUC + 1.0;
  *b_time = 5.0;
}

//
// File trailer for VMyfVoJrTg_fun.cpp
//
// [EOF]
//
