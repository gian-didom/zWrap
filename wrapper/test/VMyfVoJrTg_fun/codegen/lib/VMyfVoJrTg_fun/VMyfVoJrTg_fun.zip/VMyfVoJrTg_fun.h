//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VMyfVoJrTg_fun.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 27-Oct-2023 11:24:57
//

#ifndef VMYFVOJRTG_FUN_H
#define VMYFVOJRTG_FUN_H

// Include Files
#include "VMyfVoJrTg_fun_types.h"
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void VMyfVoJrTg_fun(double oyvELPSlUC, const char eguWQhvSLY[806075],
                           const struct0_T FieEkIcymP[24],
                           const int64m_T TWgrWEqeae[557760],
                           const cell_0 *JFDmJNevGZ, double *oyvELPSlUCmod,
                           double *b_time);

#endif
//
// File trailer for VMyfVoJrTg_fun.h
//
// [EOF]
//
