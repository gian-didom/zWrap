//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: VMyfVoJrTg_fun_types.h
//
// MATLAB Coder version            : 23.2
// C/C++ source code generated on  : 27-Oct-2023 11:24:57
//

#ifndef VMYFVOJRTG_FUN_TYPES_H
#define VMYFVOJRTG_FUN_TYPES_H

// Include Files
#include "rtwtypes.h"

// Type Definitions
struct int64m_T {
  unsigned int chunks[2];
};

struct struct0_T {
  int AlGyAsIvgK[363528];
  bool zZyADJpHqO[201168];
  bool BlXEngBqzH[758016];
  int CdCkoejhss;
  double XeNerqszEk[747075];
  int64m_T PkgsAAScKP;
  int64m_T DTVMSPoGbh[82308];
  int fRrRenWmpF;
};

struct cell_0 {
  bool f1;
  double f2[695970];
  int64m_T f3;
  char f4[498732];
  char f5[181440];
  bool f6[916548];
  float f7[396900];
  bool f8;
  float f9[698611];
  char f10;
  float f11[339300];
  float f12[41472];
  int f13[700672];
  float f14[436800];
  char f15;
  int f16;
  int f17;
  float f18;
  float f19;
  char f20;
};

#endif
//
// File trailer for VMyfVoJrTg_fun_types.h
//
// [EOF]
//
